// import 'package:firebase_messaging/firebase_messaging.dart';

// class CloudFunctionService {
//   final FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;

//   Future<void> triggerEmailNotification(String productId) async {
//     try {
//       await _firebaseMessaging.subscribeToTopic('emailNotifications');
//       await _firebaseMessaging.send(
//         RemoteMessage(
//           data: {
//             'productId': productId,
//           },
//           topic: 'emailNotifications',
//         ),
//       );
//       print('Email notification triggered successfully');
//     } catch (e) {
//       print('Error triggering email notification: $e');
//     }
//   }
// }
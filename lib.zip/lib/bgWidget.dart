import 'package:bb/logo.dart';
import 'package:flutter/material.dart';

class BgWidget extends StatelessWidget {
  const BgWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      decoration: const BoxDecoration(color: Color(0xffDEE5ED)),
      child: Stack(
        children: <Widget>[
          Positioned(
            left: 0,
            top: 896,
            child: Container(
              width: 222,
              height: 222,
              decoration: const ShapeDecoration(
                color: Color(0xFFD9D9D9),
                shape: OvalBorder(),
              ),
            ),
          ),
          Positioned(
            left: 475,
            top: 610,
            child: Container(
              width: 264,
              height: 264,
              decoration: const ShapeDecoration(
                color: Color(0xFFD9D9D9),
                shape: OvalBorder(),
              ),
            ),
          ),
          Positioned(
            left: 222,
            top: 0,
            child: Container(
              width: 179,
              height: 179,
              decoration: const ShapeDecoration(
                color: Color(0xFFD9D9D9),
                shape: OvalBorder(),
              ),
            ),
          ),
          Positioned(
            left: 372.08,
            top: 817.34,
            child: Transform(
              transform: Matrix4.identity()
                ..translate(0.0, 0.0)
                ..rotateZ(-0.10),
              child: Container(
                width: 95.48,
                height: 95.48,
                decoration: const ShapeDecoration(
                  color: Color(0xFFD9D9D9),
                  shape: OvalBorder(),
                ),
              ),
            ),
          ),
          Positioned(
            left: 332,
            top: 643.31,
            child: Transform(
              transform: Matrix4.identity()
                ..translate(0.0, 0.0)
                ..rotateZ(-0.10),
              child: Container(
                width: 63.37,
                height: 63.37,
                decoration: const ShapeDecoration(
                  color: Color(0xFFD9D9D9),
                  shape: OvalBorder(),
                ),
              ),
            ),
          ),
          Positioned(
            left: 235,
            top: 803.31,
            child: Transform(
              transform: Matrix4.identity()
                ..translate(0.0, 0.0)
                ..rotateZ(-0.10),
              child: Container(
                width: 63.37,
                height: 63.37,
                decoration: const ShapeDecoration(
                  color: Color(0xFFD9D9D9),
                  shape: OvalBorder(),
                ),
              ),
            ),
          ),
          Positioned(
            left: 332,
            top: 907.14,
            child: Transform(
              transform: Matrix4.identity()
                ..translate(0.0, 0.0)
                ..rotateZ(-0.10),
              child: Container(
                width: 41.62,
                height: 41.62,
                decoration: const ShapeDecoration(
                  color: Color(0xFFD9D9D9),
                  shape: OvalBorder(),
                ),
              ),
            ),
          ),
          Positioned(
            left: 386,
            top: 156.14,
            child: Transform(
              transform: Matrix4.identity()
                ..translate(0.0, 0.0)
                ..rotateZ(-0.10),
              child: Container(
                width: 41.62,
                height: 41.62,
                decoration: const ShapeDecoration(
                  color: Color(0xFFD9D9D9),
                  shape: OvalBorder(),
                ),
              ),
            ),
          ),
          Positioned(
            left: 509,
            top: 104.14,
            child: Transform(
              transform: Matrix4.identity()
                ..translate(0.0, 0.0)
                ..rotateZ(-0.10),
              child: Container(
                width: 41.62,
                height: 41.62,
                decoration: const ShapeDecoration(
                  color: Color(0xFFD9D9D9),
                  shape: OvalBorder(),
                ),
              ),
            ),
          ),
          Positioned(
            left: 418,
            top: 193,
            child: Container(
              width: 101,
              height: 101,
              decoration: const ShapeDecoration(
                color: Color(0xFFD9D9D9),
                shape: OvalBorder(),
              ),
            ),
          ),
          Positioned(
            left: 175,
            top: 259,
            child: Container(
              width: 70,
              height: 70,
              decoration: const ShapeDecoration(
                color: Color(0xFFD9D9D9),
                shape: OvalBorder(),
              ),
            ),
          ),
          Positioned(
            left: 161,
            top: 681,
            child: Container(
              width: 109,
              height: 109,
              decoration: const ShapeDecoration(
                color: Color(0xFFD9D9D9),
                shape: OvalBorder(),
              ),
            ),
          ),
          Positioned(
            left: 78,
            top: 498,
            child: Container(
              width: 59,
              height: 59,
              decoration: const ShapeDecoration(
                color: Color(0xFFD9D9D9),
                shape: OvalBorder(),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

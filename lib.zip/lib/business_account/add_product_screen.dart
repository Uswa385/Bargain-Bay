// ignore: file_names
// ignore_for_file: avoid_print, use_build_context_synchronously

import 'package:bb/bgWidget.dart';
import 'package:bb/consts.dart';
import 'package:bb/firebase_service.dart';
import 'package:bb/product_model.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_datetime_picker/flutter_datetime_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

import 'package:styled_widget/styled_widget.dart';

class AddProductPage extends StatefulWidget {
  const AddProductPage({super.key});

  @override
  _AddProductPageState createState() => _AddProductPageState();
}

class _AddProductPageState extends State<AddProductPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _minBidController = TextEditingController();
  final TextEditingController _maxBidController = TextEditingController();
  final TextEditingController _priceController = TextEditingController();
  final FirebaseService _firebaseService = FirebaseService();
  DateTime _endTime = DateTime.now();
  final List<File> _imageFiles = [];
  final ImagePicker _picker = ImagePicker();
  String _selectedCategory = 'Electronics';
  String _selectedType = 'Bidable';

  final List<String> _categories = [
    'Electronics',
    'Clothing & Accessories',
    'Beauty & Personal Care',
    'Sports & Outdoors',
    'Toys & Games',
    'Health & Fitness',
    'Books & Stationery',
  ];

  final List<String> _types = [
    'Bidable',
    'Bargainable',
  ];

  void _saveProduct() async {
    if (_formKey.currentState!.validate()) {
      try {
        List<String> imageUrls = [];
        if (_imageFiles.isNotEmpty) {
          imageUrls = await _firebaseService.uploadProductImages(_imageFiles);
        }

        double? minBid;
        double? maxBid;
        double? price;

        if (_selectedType == 'Bidable') {
          minBid = double.parse(_minBidController.text);
          maxBid = double.parse(_maxBidController.text);
        } else if (_selectedType == 'Bargainable') {
          price = double.parse(_priceController.text);
        }

        Product product = Product(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          name: _nameController.text,
          description: _descriptionController.text,
          minBid: minBid,
          maxBid: maxBid,
          price: price,
          ownerId: FirebaseAuth.instance.currentUser!.uid,
          imageUrls: imageUrls,
          category: _selectedCategory,
          type: _selectedType,
          createdAt: DateTime.now(),
          endTime: _endTime,
        );

        await _firebaseService.addProduct(product);
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Product added successfully')));

        Navigator.pop(context);
      } catch (e) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Error adding product: $e')));
      }
    }
  }

  Future<void> _pickEndTime() async {
    DatePicker.showDateTimePicker(context, showTitleActions: true,
        onConfirm: (date) {
          setState(() {
            _endTime = date;
          });
        }, currentTime: DateTime.now(), locale: LocaleType.en);
  }

  Future<void> _pickImages() async {
    try {
      final pickedFiles = await _picker.pickMultiImage();
      setState(() {
        _imageFiles.addAll(
            pickedFiles.map((pickedFile) => File(pickedFile.path)).toList());
      });
        } catch (e) {
      print('Error picking images: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        centerTitle: true,
        title: const Text(
          "Add Product",
          style: TextStyle(
            color: primary,
            fontSize: 25,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Stack(
          children: [
            const BgWidget(),
            Column(
              children: [
                const SizedBox(height: 100),
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        const SizedBox(height: 10),
                        TextFormField(
                          controller: _nameController,
                          decoration:
                          const InputDecoration(labelText: 'Product Name'),
                          validator: (value) =>
                          value!.isEmpty ? 'Enter product name' : null,
                        ),
                        const SizedBox(height: 10),
                        TextFormField(
                          controller: _descriptionController,
                          decoration: const InputDecoration(
                              labelText: 'Product Description'),
                          validator: (value) => value!.isEmpty
                              ? 'Enter product description'
                              : null,
                        ),
                        const SizedBox(height: 20),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Type:',
                              style: TextStyle(fontSize: 16),
                            ),
                            Row(
                              children: [
                                ..._types.map(
                                      (type) => Expanded(
                                    child: RadioListTile<String>(
                                      contentPadding: EdgeInsets.zero,
                                      title: Text(type),
                                      value: type,
                                      groupValue: _selectedType,
                                      onChanged: (value) {
                                        setState(() {
                                          _selectedType = value!;
                                        });
                                      },
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        AnimatedSwitcher(
                          duration: const Duration(milliseconds: 500),
                          child: _selectedType == 'Bidable'
                              ? Column(
                            children: [
                              TextFormField(
                                controller: _minBidController,
                                decoration: const InputDecoration(
                                    labelText: 'Minimum Bid'),
                                keyboardType: TextInputType.number,
                                validator: (value) => value!.isEmpty
                                    ? 'Enter minimum bid'
                                    : null,
                              ),
                              const SizedBox(height: 10),
                              TextFormField(
                                controller: _maxBidController,
                                decoration: const InputDecoration(
                                    labelText: 'Maximum Bid'),
                                keyboardType: TextInputType.number,
                                validator: (value) => value!.isEmpty
                                    ? 'Enter maximum bid'
                                    : null,
                              ),
                              const SizedBox(height: 10),
                              TextButton.icon(
                                icon: const Icon(Icons.timer),
                                label: Text(
                                    "End Time: ${_endTime.toLocal()}"),
                                onPressed: _pickEndTime,
                              ),
                            ],
                          )
                              : TextFormField(
                            key: UniqueKey(),
                            controller: _priceController,
                            decoration:
                            const InputDecoration(labelText: 'Price'),
                            keyboardType: TextInputType.number,
                            validator: (value) =>
                            value!.isEmpty ? 'Enter price' : null,
                          ),
                        ),
                        const SizedBox(height: 10),
                        DropdownButtonFormField<String>(
                          value: _selectedCategory.isNotEmpty
                              ? _selectedCategory
                              : null,
                          decoration:
                          const InputDecoration(labelText: 'Category'),
                          items: _categories.map((String category) {
                            return DropdownMenuItem<String>(
                              value: category,
                              child: Text(category),
                            );
                          }).toList(),
                          onChanged: (String? newValue) {
                            setState(() {
                              _selectedCategory = newValue!;
                            });
                          },
                        ),
                        const SizedBox(height: 10),
                        _imageFiles.isNotEmpty
                            ? GridView.count(
                          crossAxisCount: 3,
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          children: _imageFiles
                              .map(
                                (imageFile) => Padding(
                              padding: const EdgeInsets.all(4.0),
                              child: Image.file(
                                imageFile,
                                width: 100,
                                height: 100,
                                fit: BoxFit.cover,
                              ),
                            ),
                          )
                              .toList(),
                        )
                            : const Text('No images selected'),
                        TextButton.icon(
                          icon: const Icon(Icons.image),
                          label: const Text('Select Images'),
                          onPressed: _pickImages,
                        ),
                        const SizedBox(height: 20),
                        GestureDetector(
                          onTap: _saveProduct,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 40, vertical: 15),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: primary,
                            ),
                            child: const Text(
                              'Add Product',
                              style:
                              TextStyle(color: Colors.white, fontSize: 20),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                )
                    .card(
                  elevation: 5,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  color: secondary,
                )
                    .padding(horizontal: 20),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';

const secondary = Color(0xFFD9D9D9);
const primary = Colors.brown;
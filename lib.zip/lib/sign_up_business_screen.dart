import 'dart:io';

import 'package:bb/auth_service.dart';
import 'package:bb/bgWidget.dart';
import 'package:bb/consts.dart';
import 'package:bb/login.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:email_otp/email_otp.dart';
import 'package:styled_widget/styled_widget.dart';

class BusinessSignUpScreen extends StatefulWidget {
  const BusinessSignUpScreen({Key? key}) : super(key: key);

  @override
  State<BusinessSignUpScreen> createState() => _BusinessSignUpScreenState();
}

class _BusinessSignUpScreenState extends State<BusinessSignUpScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _phoneNumberController = TextEditingController();
  final TextEditingController _otpController = TextEditingController();
  final AuthService _authService = AuthService();

  File? _profileImage;
  EmailOTP myauth = EmailOTP();

  final TextEditingController _passwordController = TextEditingController();

  Future<void> _pickProfileImage() async {
    final pickedFile =
        await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _profileImage = File(pickedFile.path);
      });
    }
  }

  Future<void> _sendOTP() async {
    String email = _emailController.text.trim();
    myauth.setConfig(
        appEmail: "fypbargainbay@gmail.com",
        appName: "Bargain Bay",
        userEmail: _emailController.text,
        otpLength: 6,
        otpType: OTPType.digitsOnly);
    if (await myauth.sendOTP() == true) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text("OTP has been sent"),
      ));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text("Oops, OTP send failed"),
      ));
    }
  }

  Future<bool> _verifyOTP() async {
    String otp = _otpController.text.trim();
    if (await myauth.verifyOTP(otp: _otpController.text) == true) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text("OTP is verified"),
      ));
      return true;
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text("Invalid OTP"),
      ));
      return false;
    }
  }

  bool _isValidEmail(String email) {
    final regex = RegExp(r'^[^@]+@[^@]+\.[^@]+');
    return regex.hasMatch(email);
  }

  void _showErrorSnackbar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Stack(
          children: <Widget>[
            const BgWidget(),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                const SizedBox(
                  height: 50,
                ),
                IconButton(
                  icon: const Icon(
                    Icons.arrow_circle_left,
                    color: Colors.brown,
                  ),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
                const Center(
                  child: Text(
                    "Signup For Your Business!",
                    style: TextStyle(color: Colors.brown, fontSize: 30),
                  ),
                ),
                const SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: const Color(0xffD9D9D9),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20.0, vertical: 10),
                      child: Column(
                        children: [
                          GestureDetector(
                            onTap: _pickProfileImage,
                            child: CircleAvatar(
                              backgroundColor: Colors.grey[500],
                              backgroundImage: _profileImage != null
                                  ? FileImage(_profileImage!)
                                  : null,
                              radius: 50,
                              child: _profileImage == null
                                  ? const Icon(
                                      Icons.add_a_photo,
                                      size: 30,
                                      color: Colors.white,
                                    )
                                  : null,
                            ),
                          ),
                          TextFormField(
                            controller: _usernameController,
                            decoration: const InputDecoration(
                              hintText: "Business Name",
                              hintStyle: TextStyle(color: Colors.brown),
                              border: UnderlineInputBorder(
                                borderSide:
                                    BorderSide(color: Colors.brown, width: 2),
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          TextFormField(
                            controller: _emailController,
                            keyboardType: TextInputType.emailAddress,
                            decoration: InputDecoration(
                              hintText: "Business Email",
                              hintStyle: TextStyle(color: Colors.brown),
                              border: const UnderlineInputBorder(
                                borderSide:
                                    BorderSide(color: Colors.brown, width: 2),
                              ),
                              suffixIcon: TextButton(
                                onPressed: _sendOTP,
                                style: ButtonStyle(
                                  foregroundColor:
                                      WidgetStateProperty.all(primary),
                                ),
                                child: const Text("Send OTP"),
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          TextFormField(
                            controller: _phoneNumberController,
                            keyboardType: TextInputType.phone,
                            decoration: const InputDecoration(
                              hintText: "Phone Number",
                              hintStyle: TextStyle(color: Colors.brown),
                              border: UnderlineInputBorder(
                                borderSide:
                                    BorderSide(color: Colors.brown, width: 2),
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          TextFormField(
                            controller: _otpController,
                            keyboardType: TextInputType.number,
                            decoration: InputDecoration(
                              hintText: "OTP Here...",
                              hintStyle: const TextStyle(color: Colors.brown),
                              border: const UnderlineInputBorder(
                                borderSide:
                                    BorderSide(color: Colors.brown, width: 2),
                              ),
                              suffixIcon: TextButton(
                                onPressed: _verifyOTP,
                                style: const ButtonStyle(
                                    foregroundColor:
                                        WidgetStatePropertyAll(primary)),
                                child: const Text("Verify OTP"),
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          TextFormField(
                            controller: _passwordController,
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(
                              hintText: "Password",
                              hintStyle: TextStyle(color: Colors.brown),
                              border: UnderlineInputBorder(
                                borderSide:
                                    BorderSide(color: Colors.brown, width: 2),
                              ),
                            ),
                          ),
                          const SizedBox(height: 40),
                          GestureDetector(
                            onTap: _signUp,
                            child: Container(
                              height: 50,
                              width: double.infinity,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                color: Colors.brown,
                                borderRadius: BorderRadius.circular(5),
                              ),
                              child: const Text(
                                "Sign Up",
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              IconButton(
                                onPressed: () {},
                                icon: const FaIcon(FontAwesomeIcons.google),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ).card(elevation: 5),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _signUp() async {
    try {
      if (_isValidEmail(_emailController.text.trim())) {
        String imageURL = '';

        if (_profileImage != null) {
          final Reference storageRef = FirebaseStorage.instance
              .ref()
              .child('profile_images/${_profileImage!.path.split('/').last}');
          final UploadTask uploadTask = storageRef.putFile(_profileImage!);
          final TaskSnapshot snapshot = await uploadTask;
          imageURL = await snapshot.ref.getDownloadURL();

          User? user = await _authService.registerWithEmail(
              isShopping: false,
              email: _emailController.text.trim(),
              password: _passwordController.text.trim(),
              username: _usernameController.text.trim(),
              phone: _phoneNumberController.text.trim(),
              imageURL: imageURL);
          if (user != null) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => const Login(),
              ),
            );
          }
        } else {
          _showErrorSnackbar("Please Upload Image");
        }
      }
    } catch (e) {
      _showErrorSnackbar('Error: $e');
    }
  }
}

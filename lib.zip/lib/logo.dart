import 'package:flutter/material.dart';


class Logo extends StatelessWidget {
  const Logo({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 200,
      width: 200,
      decoration: const ShapeDecoration(
        color: Color(0xFFD9D9D9),
        shape: OvalBorder(),
      ),
      child: Image.asset('assets/bg.png', fit: BoxFit.cover,),
    );
  }
}

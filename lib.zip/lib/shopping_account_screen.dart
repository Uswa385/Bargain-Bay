import 'package:bb/admin/review.dart';
import 'package:bb/auth_service.dart';
import 'package:bb/bgWidget.dart';
import 'package:bb/consts.dart';
import 'package:bb/porduct_list.dart';
import 'package:bb/shopping_profile.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:styled_widget/styled_widget.dart';

class ShoppingAccountDashboard extends StatefulWidget {
  const ShoppingAccountDashboard({Key? key}) : super(key: key);

  @override
  State<ShoppingAccountDashboard> createState() =>
      _ShoppingAccountDashboardState();
}

class _ShoppingAccountDashboardState extends State<ShoppingAccountDashboard> {
  final List<String> categories = [
    'Electronics',
    'Clothing & Accessories',
    'Beauty & Personal Care',
    'Sports & Outdoors',
    'Toys & Games',
    'Health & Fitness',
    'Books & Stationery',
  ];

  final List<String> categoryImages = [
    'assets/electronics.jpg',
    'assets/clothing.jpg',
    'assets/beauty.jpg',
    'assets/sports.jpg',
    'assets/toys.jpg',
    'assets/health.jpg',
    'assets/books.jpg',
  ];

  List<String> filteredCategories = [];
  List<String> filteredCategoryImages = [];
  final TextEditingController _searchController = TextEditingController();
  final AuthService _authService = AuthService();

  @override
  void initState() {
    super.initState();
    filteredCategories = categories;
    filteredCategoryImages = categoryImages;
    _searchController.addListener(_filterCategories);
  }

  void _filterCategories() {
    String query = _searchController.text.toLowerCase();
    setState(() {
      if (query.isEmpty) {
        filteredCategories = categories;
        filteredCategoryImages = categoryImages;
      } else {
        filteredCategories = categories
            .where((category) => category.toLowerCase().contains(query))
            .toList();
        filteredCategoryImages = [];
        for (var category in filteredCategories) {
          int index = categories.indexOf(category);
          filteredCategoryImages.add(categoryImages[index]);
        }
      }
    });
  }

  void _signOut() {
    _authService.signOut();
    Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
  }

  @override
  void dispose() {
    _searchController.removeListener(_filterCategories);
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: primary,
        title: const Text(
          "Bargain Bay",
          style: TextStyle(color: Colors.white),
        ),
        actions: [
          const Icon(
            FontAwesomeIcons.sliders,
            color: Colors.white,
          ).padding(right: 10),
        ],
      ),
      body: Stack(
        children: [
          const BgWidget(),
          Column(
            children: <Widget>[
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                width: double.infinity,
                decoration: const BoxDecoration(
                  color: primary,
                ),
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: TextField(
                    controller: _searchController,
                    autofocus: false, // Ensure autofocus is set to false
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide.none,
                      ),
                      hintText: "Search",
                      suffixIcon: const Icon(Icons.search),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Expanded(
                child: GridView.builder(
                  itemCount: filteredCategories.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 10.0,
                    crossAxisSpacing: 10.0,
                  ),
                  itemBuilder: (BuildContext context, int index) {
                    return GestureDetector(
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ProductListScreen(
                            category: filteredCategories[index],
                          ),
                        ),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Stack(
                          children: <Widget>[
                            Image.asset(
                              filteredCategoryImages[index],
                              width: 200,
                              height: 200,
                              fit: BoxFit.cover,
                            ),
                            Positioned(
                              bottom: 0,
                              left: 0,
                              right: 0,
                              child: Container(
                                height: 60,
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.5),
                                  borderRadius: const BorderRadius.only(
                                    bottomLeft: Radius.circular(10),
                                    bottomRight: Radius.circular(10),
                                  ),
                                ),
                                child: Text(
                                  filteredCategories[index],
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ).padding(horizontal: 10, vertical: 10),
                    );
                  },
                ),
              ),
            ],
          ),
        ],
      ),
      drawer: Drawer(
        backgroundColor: primary,
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            const DrawerHeader(
              child: Row(
                children: [
                  Text("Dashboard", style: TextStyle(color: Colors.white)),
                  SizedBox(width: 20),
                  Icon(
                    FontAwesomeIcons.grip,
                    color: Colors.white,
                  ),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(
                FontAwesomeIcons.arrowRightFromBracket,
                color: Colors.white,
              ),
              title:
                  const Text("Sign Out", style: TextStyle(color: Colors.white)),
              onTap: _signOut,
            ),
            ListTile(
              leading: const Icon(FontAwesomeIcons.person, color: Colors.white),
              title:
                  const Text("Profile", style: TextStyle(color: Colors.white)),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const ShoppingProfile(),
                ),
              ),
            ),
            ListTile(
              leading: const Icon(FontAwesomeIcons.star, color: Colors.white),
              title:
                  const Text("Review", style: TextStyle(color: Colors.white)),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const ReviewScreen(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

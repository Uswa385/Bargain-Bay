import 'package:bb/bgWidget.dart';
import 'package:bb/bottom_navigation.dart';
import 'package:bb/consts.dart';
import 'package:flutter/material.dart';

class StatisticsScreen extends StatelessWidget {
  const StatisticsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bargain Bay'),
        backgroundColor: primary,
        foregroundColor: Colors.white,
      ),
      body: Stack(
        children: [
          const BgWidget(),
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        const Text(
                          'Statistics',
                          style: TextStyle(fontSize: 24, color: primary),
                        ),
                        const SizedBox(height: 20),
                        card(
                          title: "Confirmed Orders",
                          imagePath: 'assets/Order Completed.png',
                          onTap: () {},
                        ),
                        card(
                          title: "Ready for delivery",
                          imagePath: 'assets/Delivery.png',
                          onTap: () {},
                        ),
                        card(
                          title: "Item on the way",
                          imagePath: 'assets/Around the Globe.png',
                          onTap: () {},
                        ),
                        card(
                          title: "Delivered order",
                          imagePath: 'assets/Group 20.png',
                          onTap: () {},
                        ),
                        card(
                          title: "Refunded order",
                          imagePath: 'assets/Sync.png',
                          onTap: () {},
                        ),
                        const SizedBox(height: 50),
                        const Text(
                          "Earning",
                          style: TextStyle(color: primary, fontSize: 20),
                        ),
                        const Card(
                          elevation: 4,
                          color: secondary,
                          child: Column(children: [
                            Padding(
                              padding: EdgeInsets.all(8.0),
                              child: Text("Total item sold: 6078 items",
                                  style:
                                      TextStyle(color: primary, fontSize: 14)),
                            ),
                            Padding(
                              padding: EdgeInsets.all(8.0),
                              child: Text("Total Sale: \$61172",
                                  style:
                                      TextStyle(color: primary, fontSize: 14)),
                            ),
                            Padding(
                              padding: EdgeInsets.all(8.0),
                              child: Text("Total commission given: \$6134",
                                  style:
                                      TextStyle(color: primary, fontSize: 14)),
                            ),
                          ]),
                        ),
                      ],
                    ),
                  ),
                ),
                BNB(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class card extends StatelessWidget {
  const card({
    super.key,
    required this.title,
    required this.imagePath,
    required this.onTap,
  });

  final String title;
  final String imagePath;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4.0,
      margin: const EdgeInsets.all(16.0),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          gradient: LinearGradient(
            colors: [Colors.brown[200]!, Colors.brown[900]!],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: InkWell(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  imagePath,
                  height: 48.0,
                  width: 48.0,
                ),
                const SizedBox(height: 16.0),
                Text(
                  title,
                  style: const TextStyle(fontSize: 18.0, color: Colors.white),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

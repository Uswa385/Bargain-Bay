class Product {
  final String id;
  final String name;
  final String description;
  final double? minBid;
  final double? maxBid;
  final double? price;
  final String ownerId;
  final List<String> imageUrls;
  final String category;
  final String type;
  final DateTime createdAt; // Add createdAt field
  final DateTime endTime; // Add endTime field

  Product({
    required this.id,
    required this.name,
    required this.description,
    this.minBid,
    this.maxBid,
    this.price,
    required this.ownerId,
    required this.imageUrls,
    required this.category,
    required this.type,
    required this.createdAt, // Add createdAt to constructor
    required this.endTime, // Add endTime to constructor
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'minBid': minBid,
      'maxBid': maxBid,
      'price': price,
      'ownerId': ownerId,
      'imageUrls': imageUrls,
      'category': category,
      'type': type,
      'createdAt': createdAt.toIso8601String(), // Convert to string
      'endTime': endTime.toIso8601String(), // Convert to string
    };
  }

  factory Product.fromMap(Map<String, dynamic> map) {
    return Product(
      id: map['id'],
      name: map['name'],
      description: map['description'],
      minBid: map['minBid']?.toDouble(),
      maxBid: map['maxBid']?.toDouble(),
      price: map['price']?.toDouble(),
      ownerId: map['ownerId'],
      imageUrls: List<String>.from(map['imageUrls']),
      category: map['category'],
      type: map['type'],
      createdAt: DateTime.parse(map['createdAt']), // Convert from string
      endTime: DateTime.parse(map['endTime']), // Convert from string
    );
  }

  Product copyWith({
    String? id,
    String? name,
    String? description,
    double? minBid,
    double? maxBid,
    double? price,
    String? ownerId,
    List<String>? imageUrls,
    String? category,
    String? type,
    DateTime? createdAt, // Add createdAt to copyWith
    DateTime? endTime, // Add endTime to copyWith
  }) {
    return Product(
      id: id ?? this.id,
      name: name ?? this.name,
      description: description ?? this.description,
      minBid: minBid ?? this.minBid,
      maxBid: maxBid ?? this.maxBid,
      price: price ?? this.price,
      ownerId: ownerId ?? this.ownerId,
      imageUrls: imageUrls ?? this.imageUrls,
      category: category ?? this.category,
      type: type ?? this.type,
      createdAt: createdAt ?? this.createdAt, // Add createdAt to copyWith
      endTime: endTime ?? this.endTime, // Add endTime to copyWith
    );
  }
}

// ignore_for_file: avoid_print, avoid_function_literals_in_foreach_calls

import 'dart:io';

import 'package:bb/product_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';

class FirebaseService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;

  Future<List<String>> uploadProductImages(List<File> images) async {
    List<String> downloadUrls = [];
    try {
      for (File image in images) {
        String fileName = DateTime.now().millisecondsSinceEpoch.toString();
        Reference ref = _storage.ref().child('product_images').child(fileName);
        UploadTask uploadTask = ref.putFile(image);
        TaskSnapshot snapshot = await uploadTask;
        String downloadUrl = await snapshot.ref.getDownloadURL();
        downloadUrls.add(downloadUrl);
      }
      return downloadUrls;
    } catch (e) {
      print('Error uploading images: $e');
      rethrow;
    }
  }

  Future<void> addProduct(Product product) async {
    try {
      await _firestore
          .collection('products')
          .doc(product.id)
          .set(product.toMap());
      print('Product added successfully');
    } catch (e) {
      print('Error adding product: $e');
      rethrow;
    }
  }

  Future<List<Product>> getProductByCategory(String category) async {
    try {
      QuerySnapshot querySnapshot = await _firestore
          .collection('products')
          .where('category', isEqualTo: category)
          .get();

      List<Product> products = [];
      querySnapshot.docs.forEach((doc) {
        products.add(Product.fromMap(doc.data() as Map<String, dynamic>));
      });
      return products;
    } catch (e) {
      print("Error fetching products by category: $e");
      return [];
    }
  }

  Future<List<Product>> getProductByCategoryAndBusiness(
      String category, String id) async {
    try {
      QuerySnapshot? querySnapshot = await _firestore
          .collection('products')
          .where('category', isEqualTo: category)
          .where('ownerId', isEqualTo: id)
          .get();

      List<Product> products = [];
      for (var doc in querySnapshot.docs) {
        if (doc.exists) {
          products.add(Product.fromMap(doc.data() as Map<String, dynamic>));
        }
      }
      return products;
    } catch (e) {
      print("Error fetching products by category and business: $e");
      return [];
    }
  }

  Future<void> updateProduct(Product product) async {
    try {
      await _firestore
          .collection('products')
          .doc(product.id)
          .update(product.toMap());
      print('Product updated successfully');
    } catch (e) {
      print('Error updating product value: $e');
      rethrow;
    }
  }

  Future<Product?> getProductById(String productId) async {
    try {
      DocumentSnapshot doc =
          await _firestore.collection('products').doc(productId).get();
      if (doc.exists) {
        return Product.fromMap(doc.data() as Map<String, dynamic>);
      } else {
        print('Product not found');
        return null;
      }
    } catch (e) {
      print('Error fetching product: $e');
      rethrow;
    }
  }

  Future<bool> isBusinessUser(String email) async {
    try {
      // Query the business collection to check if the email exists
      QuerySnapshot<Map<String, dynamic>> querySnapshot = await _firestore
          .collection('business')
          .where('email', isEqualTo: email)
          .get();

      // Check if any documents are returned
      if (querySnapshot.docs.isNotEmpty) {
        // Email exists in the business collection
        return true;
      } else {
        // Email does not exist in the business collection
        return false;
      }
    } catch (e) {
      // Handle any errors
      print("Error checking business user: $e");
      return false;
    }
  }
}

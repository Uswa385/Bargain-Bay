import 'package:bb/bgWidget.dart';
import 'package:bb/consts.dart';
import 'package:flutter/material.dart';
import 'product_model.dart';

class ProductDetailScreen extends StatelessWidget {
  final Product _product;

  const ProductDetailScreen({Key? key, required Product product})
      : _product = product,
        super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: primary,
        foregroundColor: Colors.white,
        title: Text(_product.name),
      ),
      body: Stack(
        children: [
          const BgWidget(),
          const SizedBox(height: 10),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: _product.imageUrls.isNotEmpty
                      ? Image.network(
                          _product.imageUrls[0], // Display the first image
                          width: double.infinity,
                          height: 200,
                          fit: BoxFit.cover,
                        )
                      : const Icon(Icons.image_not_supported, size: 200),
                ),
                const SizedBox(height: 20),
                if (_product.price == null)
                  Column(
                    children: [
                      Row(
                        children: [
                          const Text(
                            "Min Bid: ",
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          Text(_product.minBid?.toString() ?? ''),
                        ],
                      ),
                      Row(
                        children: [
                          const Text(
                            "Max Bid: ",
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          Text(_product.maxBid?.toString() ?? ''),
                        ],
                      ),
                    ],
                  )
                else
                  Text(
                    'Price: \$${_product.price!.toStringAsFixed(2)}',
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                const SizedBox(height: 10),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: secondary,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Description',
                        style: TextStyle(fontSize: 16, color: primary),
                      ),
                      Text(_product.description)
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: Container(
        width: 200,
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: FloatingActionButton(
          elevation: 5,
          backgroundColor: primary,
          isExtended: true,
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(20),
              topRight: Radius.circular(20),
            ),
          ),
          onPressed: () {
            Navigator.of(context).pushNamed(
              '/bid',
              arguments: _product,
            );
          },
          child: _product.price == null
              ? const Text(
                  "Bid",
                  style: TextStyle(color: Colors.white, fontSize: 20),
                )
              : const Text(
                  "Bargain",
                  style: TextStyle(color: Colors.white, fontSize: 20),
                ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
}

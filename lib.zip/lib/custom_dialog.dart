import 'package:bb/consts.dart';
import 'package:bb/sign_up_business_screen.dart';
import 'package:bb/signup.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'dart:ui';

class CustomDialog extends StatelessWidget {
  const CustomDialog({super.key});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20.0),
      ),
      elevation: 12.0, // Adding elevation for shadow effect
      backgroundColor: Colors.transparent, // Make dialog background transparent
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10.0, sigmaY: 10.0),
        // Apply blur effect
        child: Container(
          padding: const EdgeInsets.all(20.0),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.2), // Semi-transparent background
            borderRadius: BorderRadius.circular(20.0),
            border: Border.all(
              color: Colors.white.withOpacity(0.3), // Semi-transparent border
              width: 1.5,
            ),
            boxShadow: const [
              BoxShadow(
                color: Colors.black26, // Shadow color
                blurRadius: 10.0, // Shadow blur radius
                offset: Offset(0, 10), // Shadow offset
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              const Text(
                'Sign Up',
                style: TextStyle(
                  fontSize: 24.0,
                  fontWeight: FontWeight.bold,
                  color: secondary, // Adjust the color if necessary
                ),
              ),
              const SizedBox(height: 10.0),
              const Text(
                "Let's get started",
                style: TextStyle(
                  fontSize: 20.0,
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10.0),
              const Text(
                'Glad to have you with us',
                style: TextStyle(
                  fontSize: 18.0,
                  color: Colors.white70,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 10.0),
              const Text(
                'What would you like to sign up for?',
                style: TextStyle(
                  fontSize: 18.0,
                  color: Colors.white, // Text color
                ),
                textAlign: TextAlign.center, // Center align the text
              ),
              const SizedBox(height: 20.0),
              const Text(
                'Choosing our app means choosing the best in class for all your business and shopping needs. We are dedicated to providing you with top-notch services and a seamless experience.',
                style: TextStyle(
                  fontSize: 14.0,
                  color: Colors.white, // Paragraph text color
                ),
                textAlign: TextAlign.center, // Center align the text
              ),
              const SizedBox(height: 20.0),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      foregroundColor: Colors.white,
                      backgroundColor: primary,
                      // Text color of the button
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      padding: const EdgeInsets.symmetric(
                        vertical: 10.0,
                        horizontal: 20.0,
                      ),
                    ),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const BusinessSignUpScreen()),
                      );
                    },
                    child: const Text(
                      'Business',
                      style: TextStyle(fontSize: 16.0),
                    ),
                  ),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      foregroundColor: Colors.white,
                      backgroundColor: primary,
                      // Text color of the button
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      padding: const EdgeInsets.symmetric(
                        vertical: 10.0,
                        horizontal: 20.0,
                      ),
                    ),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const SignUp()),
                      );
                    },
                    child: const Text(
                      'Shopping',
                      style: TextStyle(fontSize: 16.0),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ).animate().fadeIn(duration: const Duration(milliseconds: 500)).slide(
              begin:
                  const Offset(0, 1), // Start position (bottom of the screen)
              end: const Offset(0, 0), // End position (middle of the screen)
              curve: Curves.easeOut,
            ),
      ),
    );
  }
}

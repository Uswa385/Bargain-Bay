import 'package:bb/bgWidget.dart';
import 'package:bb/consts.dart';
import 'package:bb/custom_dialog.dart';
import 'package:bb/login.dart';
import 'package:bb/logo.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class LoginSignupPage extends StatefulWidget {
  const LoginSignupPage({super.key});

  @override
  State<LoginSignupPage> createState() => _LoginSignupPageState();
}

class _LoginSignupPageState extends State<LoginSignupPage> {
  void _showAnimatedDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return const CustomDialog();
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        const BgWidget(),
        Padding(
          padding: const EdgeInsets.only(left: 20.0, right: 20.0, top: 100.0),
          child: Column(
            children: [
              const Center(child: Logo()),
              const SizedBox(height: 100),
              const DefaultTextStyle(
                style: TextStyle(
                  fontSize: 20,
                  color: Colors.brown,
                ),
                child: Text(
                  "Your Privacy Matters. Rest assured, we strictly safeguard your information. We do not share, sell, or compromise your data. Welcome to a secure login experience.",
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 20),
              GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const Login(),
                    ),
                  );
                },
                child: Container(
                  height: 50,
                  width: double.infinity,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: Colors.brown,
                    borderRadius: BorderRadius.circular(5),
                  ),
                  child: const DefaultTextStyle(
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                    ),
                    child: Text(
                      "LOGIN",
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              GestureDetector(
                onTap: () {
                  _showAnimatedDialog(context);
                },
                child: Container(
                  height: 50,
                  width: double.infinity,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: primary,
                    borderRadius: BorderRadius.circular(5),
                  ),
                  child: const DefaultTextStyle(
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                    ),
                    child: Text(
                      "CREATE AN ACCOUNT",
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    onPressed: () {
                    },
                    icon: const FaIcon(FontAwesomeIcons.google),
                  ),
                  IconButton(
                    onPressed: () {},
                    icon: const FaIcon(FontAwesomeIcons.phone),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

}

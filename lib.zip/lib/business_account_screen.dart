import 'package:bb/bgWidget.dart';
import 'package:bb/bottom_navigation.dart';
import 'package:bb/business_category.dart';
import 'package:bb/consts.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class BusinessAccountDashboard extends StatelessWidget {
  const BusinessAccountDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Business Dashboard'),
        backgroundColor: primary,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        child: Stack(
          children: [
            const BgWidget(),
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: Column(
                      children: [
                        const Text(
                          'Dashboard',
                          style: TextStyle(fontSize: 24, color: primary),
                        ),
                        const SizedBox(height: 20),
                        DashboardCard(
                          title: "View Products",
                          icon: Icons.list,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => const BAD(),
                              ),
                            );
                          },
                        ),
                        DashboardCard(
                          title: "Statistics",
                          icon: FontAwesomeIcons.chartLine,
                          onTap: () {
                            // Navigator.push(
                            //   context,
                            //   MaterialPageRoute(
                            //     builder: (context) => const StatisticsScreen(),
                            //   ),
                            // );
                          },
                        ),
                        DashboardCard(
                          title: "Notifications",
                          icon: FontAwesomeIcons.bell,
                          onTap: () {},
                        ),
                      ],
                    ),
                  ),
                  BNB(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class DashboardCard extends StatelessWidget {
  const DashboardCard({
    super.key,
    required this.title,
    required this.icon,
    required this.onTap,
  });

  final String title;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4.0,
      margin: const EdgeInsets.all(16.0),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          gradient: LinearGradient(
            colors: [Colors.brown[200]!, Colors.brown[900]!],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: InkWell(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  icon,
                  size: 48.0,
                  color: Colors.white,
                ),
                const SizedBox(height: 16.0),
                Text(
                  title,
                  style: const TextStyle(fontSize: 18.0, color: Colors.white),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firebaseStore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;

  get user => _auth.currentUser;

  // Sign in with email and password
  Future<User?> signInWithEmail(String email, String password) async {
    try {
      UserCredential result = await _auth.signInWithEmailAndPassword(
          email: email, password: password);
      return result.user;
    } catch (e) {
      print(e.toString());
      return null;
    }
  }

  // Register with email and password
  Future<User?> registerWithEmail({
    required bool? isShopping,
    required String email,
    required String password,
    required String username,
    required String phone,
    required String imageURL,
  }) async {
    try {
      UserCredential result = await _auth.createUserWithEmailAndPassword(
          email: email, password: password);

      if (isShopping == true) {
        await _firebaseStore.collection('shopping').doc(result.user!.uid).set({
          'username': username,
          'email': email,
          'phone': phone,
          'imageURL': imageURL,
          'uid': result.user!.uid,
        });
      } else {
        await _firebaseStore.collection('business').doc(result.user!.uid).set({
          'username': username,
          'email': email,
          'phone': phone,
          'imageURL': imageURL,
          'uid': result.user!.uid,
        });
      }

      return result.user;
    } catch (e) {
      print(e.toString());

      return null;
    }
  }

  Future<String?> uploadProfilePicture(File imageFile, String userId) async {
    try {
      String fileName =
          'profile_$userId.jpg'; // Define a unique file name for the image
      Reference ref = _storage.ref().child('profile_pictures').child(fileName);
      await ref.putFile(imageFile);
      String downloadUrl = await ref.getDownloadURL();
      return downloadUrl;
    } catch (e) {
      print('Error uploading profile picture: $e');
      return null;
    }
  }

  Future<void> signOut() async {
    try {
      return await _auth.signOut();
    } catch (e) {
      print(e.toString());
      return;
    }
  }
}

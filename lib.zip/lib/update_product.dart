// ignore_for_file: library_private_types_in_public_api
import 'dart:io';

import 'package:bb/bgWidget.dart';
import 'package:bb/consts.dart';
import 'package:bb/firebase_service.dart';
import 'package:bb/product_model.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:styled_widget/styled_widget.dart';

class UpdateProductPage extends StatefulWidget {
  final String productId;

  const UpdateProductPage({super.key, required this.productId});

  @override
  _UpdateProductPageState createState() => _UpdateProductPageState();
}

class _UpdateProductPageState extends State<UpdateProductPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _minBidController = TextEditingController();
  final TextEditingController _maxBidController = TextEditingController();
  final TextEditingController _priceController = TextEditingController();
  final FirebaseService _firebaseService = FirebaseService();
  late Product? product;
  List<File> _imageFiles = [];
  final ImagePicker _picker = ImagePicker();
  String _selectedCategory = 'Electronics';
  String _selectedType = 'Biddable';

  final List<String> _categories = [
    'Electronics',
    'Clothing & Accessories',
    'Beauty & Personal Care',
    'Sports & Outdoors',
    'Toys & Games',
    'Health & Fitness',
    'Books & Stationery',
  ];

  final List<String> _types = [
    'Biddable',
    'Bargainable',
  ];

  @override
  void initState() {
    super.initState();
    _fetchProductData();
  }

  Future<void> _fetchProductData() async {
    try {
      product = await _firebaseService.getProductById(widget.productId);
      setState(() {
        _nameController.text = product!.name;
        _descriptionController.text = product!.description;
        _selectedCategory = product!.category;
        _selectedType = product!.type;
        if (_selectedType == 'Biddable') {
          _minBidController.text = product!.minBid?.toString() ?? '';
          _maxBidController.text = product!.maxBid?.toString() ?? '';
        } else if (_selectedType == 'Bargainable') {
          _priceController.text = product!.price?.toString() ?? '';
        }
        if (product!.imageUrls.isNotEmpty) {
          _imageFiles = product!.imageUrls.map((url) => File(url)).toList();
        }
      });
    } catch (e) {
      print('Error fetching product data: $e');
    }
  }

  Future<void> _pickImages() async {
    try {
      final pickedFiles = await _picker.pickMultiImage();
      if (pickedFiles != null) {
        setState(() {
          _imageFiles.addAll(
              pickedFiles.map((pickedFile) => File(pickedFile.path)).toList());
        });
      }
    } catch (e) {
      print('Error picking images: $e');
    }
  }

  Future<void> _updateProduct() async {
    if (_formKey.currentState!.validate()) {
      try {
        List<String> imageUrls = [];
        if (_imageFiles.isNotEmpty) {
          imageUrls = await _firebaseService.uploadProductImages(_imageFiles);
        }
        Product updatedProduct = Product(
          id: widget.productId,
          name: _nameController.text,
          description: _descriptionController.text,
          category: _selectedCategory,
          type: _selectedType,
          minBid: _selectedType == 'Biddable'
              ? double.parse(_minBidController.text)
              : null,
          maxBid: _selectedType == 'Biddable'
              ? double.parse(_maxBidController.text)
              : null,
          price: _selectedType == 'Bargainable'
              ? double.parse(_priceController.text)
              : null,
          imageUrls: imageUrls,
          createdAt: product!.createdAt,
          endTime: product!.endTime,
          ownerId: product!.ownerId,
        );

        await _firebaseService.updateProduct(updatedProduct);

        Navigator.pop(context);
      } catch (e) {
        print('Error updating product: $e');
      }
    }
  }

  String? _validateForm() {
    if (_nameController.text.isEmpty) {
      return 'Enter product name';
    }
    if (_descriptionController.text.isEmpty) {
      return 'Enter product description';
    }
    if (_selectedType == 'Biddable') {
      if (_minBidController.text.isEmpty) {
        return 'Enter minimum bid';
      }
      if (_maxBidController.text.isEmpty) {
        return 'Enter maximum bid';
      }
    } else if (_selectedType == 'Bargainable') {
      if (_priceController.text.isEmpty) {
        return 'Enter price';
      }
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Update Product'),
      ),
      body: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              // Product name field
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: 'Product Name',
                ),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Enter product name';
                  }
                  return null;
                },
              ),

              // Product description field
              TextFormField(
                controller: _descriptionController,
                decoration: const InputDecoration(
                  labelText: 'Product Description',
                ),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Enter product description';
                  }
                  return null;
                },
              ),

              // Product category dropdown
              DropdownButtonFormField<String>(
                value: _selectedCategory,
                items: _categories.map((category) {
                  return DropdownMenuItem<String>(
                    value: category,
                    child: Text(category),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    _selectedCategory = value!;
                  });
                },
                decoration: const InputDecoration(
                  labelText: 'Category',
                ),
              ),

              // Product type dropdown
              DropdownButtonFormField<String>(
                value: _selectedType,
                items: _types.map((type) {
                  return DropdownMenuItem<String>(
                    value: type,
                    child: Text(type),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    _selectedType = value!;
                  });
                },
                decoration: const InputDecoration(
                  labelText: 'Type',
                ),
              ),

              // Minimum bid field (only visible for Biddable products)
              if (_selectedType == 'Biddable')
                TextFormField(
                  controller: _minBidController,
                  decoration: const InputDecoration(
                    labelText: 'Minimum Bid',
                  ),
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Enter minimum bid';
                    }
                    return null;
                  },
                ),

              // Maximum bid field (only visible for Biddable products)
              if (_selectedType == 'Biddable')
                TextFormField(
                  controller: _maxBidController,
                  decoration: const InputDecoration(
                    labelText: 'Maximum Bid',
                  ),
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Enter maximum bid';
                    }
                    return null;
                  },
                ),

              // Price field (only visible for Bargainable products)
              if (_selectedType == 'Bargainable')
                TextFormField(
                  controller: _priceController,
                  decoration: const InputDecoration(
                    labelText: 'Price',
                  ),
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Enter price';
                    }
                    return null;
                  },
                ),

              // Image picker button
              ElevatedButton(
                onPressed: _pickImages,
                child: const Text('Pick Images'),
              ),

              // Display selected images
              GridView.builder(
                shrinkWrap: true,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                ),
                itemCount: _imageFiles.length,
                itemBuilder: (context, index) {
                  return Image.file(
                    _imageFiles[index],
                    fit: BoxFit.cover,
                  );
                },
              ),

              // Update button
              ElevatedButton(
                onPressed: _updateProduct,
                child: const Text('Update Product'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

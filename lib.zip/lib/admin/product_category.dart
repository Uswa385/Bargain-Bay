import 'package:bb/bgWidget.dart';
import 'package:bb/consts.dart';
import 'package:flutter/material.dart';

class ProductCategoryScreen extends StatefulWidget {
  const ProductCategoryScreen({super.key});

  @override
  State<ProductCategoryScreen> createState() => _ProductCategoryScreenState();
}

class _ProductCategoryScreenState extends State<ProductCategoryScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Product Category'),
        backgroundColor: primary,
      ),
      body: Stack(
        children: [
          const BgWidget(),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.brown[300]!, Colors.brown[700]!],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: DataTable(
                columns: const [
                  DataColumn(label: Text('#')),
                  DataColumn(label: Text('Review ID')),
                  DataColumn(label: Text('Review Date')),
                  DataColumn(label: Text('Review information')),
                  DataColumn(label: Text('Total Amount')),
                  DataColumn(label: Text('Order Status')),
                  DataColumn(label: Text('Action')),
                ],
                rows: [
                  DataRow(cells: [
                    const DataCell(Text('1')),
                    const DataCell(Text('100098')),
                    const DataCell(Text('27 Dec 2023, 01:11:12 PM')),
                    const DataCell(Text('Alison Tyler +2 *** ***')),
                    const DataCell(Text('\$930 unpaid')),
                    const DataCell(Text('Pending')),
                    DataCell(Row(
                      children: [
                        IconButton(
                            onPressed: () {},
                            icon: const Icon(Icons.print_rounded)),
                        const SizedBox(width: 5),
                        IconButton(
                            onPressed: () {},
                            icon: const Icon(Icons.remove_red_eye)),
                      ],
                    )),
                  ]),
                  DataRow(cells: [
                    const DataCell(Text('2')),
                    const DataCell(Text('100099')),
                    const DataCell(Text('28 Dec 2023, 02:15:20 PM')),
                    const DataCell(Text('John Doe +1 *** ***')),
                    const DataCell(Text('\$850 paid')),
                    const DataCell(Text('On the way')),
                    DataCell(Row(
                      children: [
                        IconButton(
                            onPressed: () {},
                            icon: const Icon(Icons.print_rounded)),
                        const SizedBox(width: 5),
                        IconButton(
                            onPressed: () {},
                            icon: const Icon(Icons.remove_red_eye)),
                      ],
                    )),
                  ]),
                  DataRow(cells: [
                    const DataCell(Text('3')),
                    const DataCell(Text('100100')),
                    const DataCell(Text('29 Dec 2023, 03:30:25 PM')),
                    const DataCell(Text('Jane Smith +3 *** ***')),
                    const DataCell(Text('\$1230 unpaid')),
                    const DataCell(Text('Delivered')),
                    DataCell(Row(
                      children: [
                        IconButton(
                            onPressed: () {},
                            icon: const Icon(Icons.print_rounded)),
                        const SizedBox(width: 5),
                        IconButton(
                            onPressed: () {},
                            icon: const Icon(Icons.remove_red_eye)),
                      ],
                    )),
                  ]),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

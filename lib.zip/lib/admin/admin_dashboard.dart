import 'package:bb/admin/all_order.dart';
import 'package:bb/admin/on_the_way.dart';
import 'package:bb/admin/product_category.dart';
import 'package:bb/admin/review.dart';
import 'package:bb/bgWidget.dart';
import 'package:flutter/material.dart';
import 'complain.dart';
import 'deliver_order.dart';
import 'pending_order.dart';
import 'ready_to_deliver.dart';
import 'upload_image_page.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        foregroundColor: Colors.white,
        title: const Text('Admin Dashboard'),
        backgroundColor: Colors.brown,
      ),
      body: Stack(
        children: [
          const BgWidget(),
          ListView(
            padding: const EdgeInsets.all(16.0),
            children: [
              _buildFeatureTile(
                context,
                icon: Icons.shopping_bag,
                text: 'All Orders',
                destination: const AllOrders(),
              ),
              _buildFeatureTile(
                context,
                icon: Icons.report_problem,
                text: 'Complains',
                destination: const Complain(),
              ),
              _buildFeatureTile(
                context,
                icon: Icons.delivery_dining,
                text: 'Delivered Orders',
                destination: const DeliverOrder(),
              ),
              _buildFeatureTile(
                context,
                icon: Icons.local_shipping,
                text: 'On The Way Orders',
                destination: const OnTheWayOrder(),
              ),
              _buildFeatureTile(
                context,
                icon: Icons.pending_actions,
                text: 'Pending Orders',
                destination: const PendingOrder(),
              ),
              _buildFeatureTile(
                context,
                icon: Icons.category,
                text: 'Product Categories',
                destination: const ProductCategoryScreen(),
              ),
              _buildFeatureTile(
                context,
                icon: Icons.check_circle,
                text: 'Ready To Deliver',
                destination: const ReadyToDeliver(),
              ),
              _buildFeatureTile(
                context,
                icon: Icons.rate_review,
                text: 'Reviews',
                destination: const ReviewScreen(),
              ),
              _buildFeatureTile(
                context,
                icon: Icons.upload_file,
                text: 'Upload Images',
                destination: const UploadImagePage(),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFeatureTile(BuildContext context,
      {required IconData icon,
      required String text,
      required Widget destination}) {
    return Card(
      color: Colors.brown[100],
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      child: ListTile(
        leading: Icon(icon, color: Colors.brown),
        title: Text(text, style: TextStyle(color: Colors.brown[800])),
        trailing: const Icon(Icons.arrow_forward, color: Colors.brown),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => destination),
          );
        },
      ),
    );
  }
}

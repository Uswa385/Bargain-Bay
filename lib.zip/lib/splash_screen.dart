import 'package:bb/bgWidget.dart';
import 'package:bb/login_signup_screen.dart';
import 'package:bb/logo.dart';
import 'package:flutter/material.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _navigateToMainScreen();
  }
  Future<void> _navigateToMainScreen() async {
    await Future.delayed(const Duration(seconds: 3)); // Wait for 3 seconds
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (context) => const LoginSignupPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Stack(
        children: [
          BgWidget(),
          Center(
            child: Logo(),
          ),
        ],
      ),
    );
  }
}

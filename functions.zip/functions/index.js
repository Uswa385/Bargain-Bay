const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp();

exports.getHighestBid = functions.https.onCall(async (data, context) => {
  const {productId} = data;
  if (!productId) {
    throw new functions.https.HttpsError(
        "invalid-argument",
        "The function must be called with a productId",
    );
  }

  const bidsRef = admin.firestore().collection("bids");
  const querySnapshot = await bidsRef
      .where("productId", "==", productId)
      .orderBy("amount", "desc")
      .limit(1)
      .get();

  if (querySnapshot.empty) {
    return {highestBid: null};
  }

  const highestBid = querySnapshot.docs[0].data();
  return {highestBid};
});
